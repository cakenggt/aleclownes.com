import math
import time

g = 0.00000000006674 #G per second

class Vector():

    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def unit(self):
        r = math.sqrt(self.x**2 + self.y**2)
        self.x = self.x/r
        self.y = self.y/r

    def direction(self):
        d = math.atan2(self.y,self.x)
        if d < 0:
            d += 2*math.pi
        return d

    def magnitude(self):
        r = math.sqrt(self.x**2 + self.y**2)
        return r

    def multiply(self, v):
        self.x = self.x * v
        self.y = self.y * v

    def add(self, v):
        self.x = self.x + v.x
        self.y = self.y + v.y

class Location():

    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def distance(self, l):
        d = math.sqrt((self.x - l.x)**2 + (self.y - l.y)**2)
        return d

class Mass():

    def __init__(self, weight, radius, x, y, descriptor, star, orbit, start):
        self.weight = weight
        self.radius = radius
        self.x = x
        self.y = y
        self.descriptor = descriptor
        self.star = star
        self.orbit = orbit
        self.start = start

    def distance(self, m):
        sx = self.x
        sy = self.y
        mx = m.x
        my = m.y
        if sx == None:
            r = self.orbit
            m = self.star.weight
            angle = (math.sqrt((g*m)/(r**3))*time.time() + self.start)%(2*math.pi)
            sx = r*math.cos(angle) + self.star.x
            sy = r*math.sin(angle) + self.star.y
        if mx == None:
            r = m.orbit
            m = m.star.weight
            angle = (math.sqrt((g*m)/(r**3))*time.time() + m.start)%(2*math.pi)
            mx = r*math.cos(angle) + m.star.x
            my = r*math.sin(angle) + m.star.y
        d = math.sqrt((sx - mx)**2 + (sy - my)**2)
        return d

class NaturalMass(Mass):

    def __init__(self, weight, radius, x, y, descriptor, star, orbit, start, tilium, hydrogen, iron, magnesia, silica, alumina, titanium):
        Mass.__init__(self, weight, radius, x, y, descriptor, star, orbit, start)
        self.tilium = tilium
        self.hydrogen = hydrogen
        self.iron = iron
        self.magnesia = magnesia
        self.silica = silica
        self.alumina = alumina
        self.titanium = titanium
        self.name = None
        #The numbers for the ores will be fractions of the weight of the body
        #These don't need to add up to 100%, some % of the body can be unusable
        #Every time a mining calculation is done, the mass for the body is recalculated and resaved in the solarSystem

    def getXY(self):
        r = self.orbit
        m = self.star.weight
        angle = (math.sqrt((g*m)/(r**3))*time.time() + self.start)%(2*math.pi)
        x = r*math.cos(angle) + self.star.x
        y = r*math.sin(angle) + self.star.y
        return x, y

class ArtMass(Mass):

    def __init__(self, weight, radius, x, y, descriptor, star, orbit, start, vector, i):
        Mass.__init__(self, weight, radius, x, y, descriptor, star, orbit, start)
        self.vector = vector
        self.i = i #This is the id number of the artMass
        #Descriptor is whether it is a ship, station, or missile
        self.modules = [] #What modules are attached to the ship or station
        self.direction = 0.0 #What radian the ship is facing, out of 2pi
        self.thrust = 0
        self.spooling = False
        self.spool = 0.0
        
class SolarSystem():

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.masses = {}
        self.solarMass = 0
        self.name = None

    def addMass(self, m):
        self.masses[m.name] = m

    def removeMass(self, m):
        self.masses.pop(m.name)
