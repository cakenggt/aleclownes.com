import mass
import board
import pygame
import pickle
import math

#Lists are surrounded by brackets [] and tuples are surrounded by parenthesis ()
#They are the same thing except that tuples cannot be changed once created

# Sample Python/Pygame Programs
# Simpson College Computer Science
# http://programarcadegames.com/
# http://simpson.edu/computer-science/
 
# Explanation video: http://youtu.be/vRB_983kUMc
 
# Define some colors
black = (   0,   0,   0)
white = ( 255, 255, 255)
green = (   0, 255,   0)
red = ( 255,   0,   0)
blue = ( 125, 249, 255)
 
pygame.init()

colorMod = 255

ticks = 0

def starSquare(s, w, x, y):
    g = None
    for m in s.masses:
        if s.masses[m].descriptor == "Star":
            g = s.masses[m]
    starColor = ( 255, 255, g.tilium*colorMod *3.33)
    #starColor = white
    start = [int(x-(w/2)),y]
    finish = [int(x+(w/2)),y]
    pygame.draw.line(screen,starColor,start,finish,w)

def oreSquare(g, w, x, y):
    #Stars richer in hydrogen will be green, richer in tilium will be blue
    squareColor = ( 255-g.tilium*colorMod, 255-g.hydrogen * colorMod, 255-g.iron*colorMod)
    #print squareColor[0], " ", squareColor[1], " ", squareColor[2]
    start = [int(x-(w/2)),y]
    finish = [int(x+(w/2)),y]
    x = int(x)
    y = int(y)
    #pygame.draw.line(screen,squareColor,start,finish,w)
    pygame.draw.circle(screen, squareColor, [x, y], int(w))

def drawShip(g, x, y):
    color = green
    radian = g.direction
    size = g.radius
    a = [2 * size * math.cos(radian) + x, -2 * size * math.sin(radian) + y]
    b = [size * math.cos((radian + 2.094)%(math.pi*2)) + x, -1 * size * math.sin((radian + 2.094)%(math.pi*2)) + y]
    c = [size * math.cos((radian + 4.189)%(math.pi*2)) + x, -1 * size * math.sin((radian + 4.189)%(math.pi*2)) + y]
    pointlist = a, b, c
    pygame.draw.polygon(screen, color, pointlist)
    a = [2 * size * math.cos(radian) * -0.5 + x, 2 * size * math.sin(radian) * 0.5 + y]
    if g.thrust == 1:
        pointlist = a, b, c
        pygame.draw.polygon(screen, red, pointlist)
    if g.thrust == -1:
        pointlist = a, b, c
        pygame.draw.polygon(screen, red, pointlist, 1)

# Set the width and height of the screen [width,height]
size = [900,900]
screen = pygame.display.set_mode(size)
zoom = 1.0
dispCenter = [0,0]
#updates per second
ups = 20

def main(b=None):
    global size, screen, zoom, dispCenter, ups, ticks
    if b == None:
        with open('board.pk', 'rb') as input:
            b = pickle.load(input)

    # Set the width and height of the screen [width,height]

    def coordToDisplay(x, y):
        cx = ((x - dispCenter[0]) * zoom + galRadius) * xFrac 
        cy = (-1 * (y - dispCenter[1]) * zoom + galRadius) * yFrac
        return int(cx), int(cy)

    def displayToCoord(cx, cy):
        x = (cx/xFrac - galRadius)/zoom + dispCenter[0]
        y = (cy/yFrac - galRadius)/zoom * -1 + dispCenter[1]
        return x, y

    pygame.display.set_caption("Space Game")
     
    #Loop until the user clicks the close button.
    done = False
     
    # Used to manage how fast the screen updates
    clock = pygame.time.Clock()
    drag = False

    # -------- Main Program Loop -----------
    while done == False:
        # ALL EVENT PROCESSING SHOULD GO BELOW THIS COMMENT
        for event in pygame.event.get(): # User did something
            if event.type == pygame.QUIT: # If user clicked close
                done = True # Flag that we are done so we exit this loop
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 4:
                    zoom = zoom * 2
                    zoomMax = 17
                    if zoom > 2**zoomMax:
                        zoom = 2.0**zoomMax
                    #print zoom
                    dispCenter[0], dispCenter[1] = displayToCoord(event.pos[0], event.pos[1])
                if event.button == 5:
                    if zoom > 0.143:
                        mousex, mousey = displayToCoord(event.pos[0], event.pos[1])
                        zoom = zoom / 2
                        mousea, mouseb = displayToCoord(event.pos[0], event.pos[1])
                        dispCenter[0] += mousex - mousea
                        dispCenter[1] += mousey - mouseb
                if event.button == 1:
                    drag = True
            if event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    drag = False
            if event.type == pygame.MOUSEMOTION and drag:
                rel = event.rel
                for f in event.buttons:
                    if f == 1:
                        dispCenter[0] -= rel[0] * (1/xFrac) * (1/zoom)
                        dispCenter[1] += rel[1] * (1/yFrac) * (1/zoom)
                        '''
            if event.type == pygame.KEYDOWN:
                if event.key not in buttons:
                    buttons.append(event.key)
            if event.type == pygame.KEYUP:
                if event.key in buttons:
                    buttons.remove(event.key)
                    '''
                      
        # ALL EVENT PROCESSING SHOULD GO ABOVE THIS COMMENT
      
      
        # ALL GAME LOGIC SHOULD GO BELOW THIS COMMENT

        galRadius = b.galRadius
        #galRadius = board.gravLimit
        xFrac = size[0]/(galRadius*2)
        yFrac = size[1]/(galRadius*2)
     
        # ALL GAME LOGIC SHOULD GO ABOVE THIS COMMENT
     
         
     
        # ALL CODE TO DRAW SHOULD GO BELOW THIS COMMENT
         
        # First, clear the screen to white. Don't put other drawing commands
        # above this, or they will be erased with this command.
        screen.fill(black)

        #coordinate display on top of screen
        pos = pygame.mouse.get_pos()
        mx=pos[0]
        my=pos[1]
        nmx, nmy = displayToCoord(mx,my)
        fontx=pygame.font.Font(None,30)
        scoretext=fontx.render("X: "+str(nmx), 1,(255,255,255))
        screen.blit(scoretext, (0, 0))
        fonty=pygame.font.Font(None,30)
        scoretext=fonty.render("Y: "+str(nmy), 1,(255,255,255))
        screen.blit(scoretext, (0, 40))
        if b.userShip in b.artMasses:
            art = b.artMasses[b.userShip]
            sd = art.direction
            d = art.vector.direction()
            m = art.vector.magnitude()
        fontx=pygame.font.Font(None,30)
        scoretext=fontx.render("Ship Direction: "+str(sd), 1,(255,255,255))
        screen.blit(scoretext, (400, 0))
        fontx=pygame.font.Font(None,30)
        scoretext=fontx.render("Move Direction: "+str(d), 1,(255,255,255))
        screen.blit(scoretext, (400, 20))
        fontx=pygame.font.Font(None,30)
        scoretext=fontx.render("Speed: "+str(m), 1,(255,255,255))
        screen.blit(scoretext, (400, 40))
                
        #do this!!!!!!
        if zoom < 256:
            for sv in b.solarSystems:
                s = b.solarSystems[sv]
                x, y = coordToDisplay(s.x, s.y)
                starSquare(s, 2, x, y)
                #drawing system boundaries
                circRad = board.gravLimit * xFrac * zoom
                if circRad > 1:
                    pygame.draw.circle(screen, red, [x, y], int(circRad), 1)
            centerx, centery = coordToDisplay(0, 0)
            centerx = int(centerx)
            centery = int(centery)
            #pygame.draw.circle(screen, red, [centerx, centery], int(galRadius * xFrac * zoom) + 1, 1)
            pos = pygame.mouse.get_pos()
            mx=pos[0]
            my=pos[1]
            circRad = b.jumpRad * xFrac * zoom
            pygame.draw.circle(screen, blue, [mx, my], int(circRad), 1)
        if zoom >= 256:
            #only display the closest star to the display center and it's masses
            sc = None
            for sv in b.solarSystems:
                s = b.solarSystems[sv]
                if sc == None:
                    sc = s
                else:
                    distances = math.sqrt((dispCenter[0] - s.x)**2 + (dispCenter[1] - s.y)**2)
                    distancesc = math.sqrt((dispCenter[0] - sc.x)**2 + (dispCenter[1] - sc.y)**2)
                    if distances < distancesc:
                        sc = s
                scx, scy = coordToDisplay(sc.x, sc.y)
                starSquare(sc, 10, scx, scy)
            #display sc and it's masses
            for v in sc.masses:
                m = sc.masses[v]
                if m.x == None:
                    gx, gy = m.getXY()
                    x, y = coordToDisplay(gx, gy)
                else:
                    x, y = m.x, m.y
                if x < size[0] or y < size[1]:
                    if m.descriptor == "Planet":
                        oreSquare(m, 10, x, y)
                        #draw the circle orbit
                        scx = int(scx)
                        scy = int(scy)
                        planetColor = ( int(255-m.tilium*colorMod), int(255-m.hydrogen * colorMod), int(255-m.iron*colorMod))
                        planetRing = int(m.distance(sc)*xFrac*zoom)
                        if planetRing >= 1:
                            pygame.draw.circle(screen, white, [scx, scy], planetRing, 1)
                    if m.descriptor == "Asteriod":
                        oreSquare(m, 10, x, y)
        buttons = pygame.key.get_pressed()
        if b.userShip in b.artMasses:
            art = b.artMasses[b.userShip]
            if buttons[273]:
                #up arrow
                thrust = board.maxThrust
                vec = mass.Vector(thrust*math.cos(art.direction),thrust*math.sin(art.direction))
                art.vector.add(vec)
                art.thrust = 1
            if buttons[274]:
                #down arrow
                thrust = board.maxThrust
                vec = mass.Vector(thrust*math.cos(art.direction),thrust*math.sin(art.direction))
                vec.multiply(-1)
                art.vector.add(vec)
                art.thrust = -1
            if not buttons[273] and not buttons[274]:
                art.thrust = 0
            if buttons[275]:
                #right arrow
                art.direction -= 0.15
                art.direction = art.direction%(2*math.pi)
            if buttons[276]:
                #left arrow
                art.direction += 0.15
                art.direction = art.direction%(2*math.pi)
            x, y = coordToDisplay(art.x, art.y)
            if art.descriptor == "Ship":
                drawShip(art, x, y)

        #This is the gravity, ship movement, and planet movement code
        if ticks >= 20:
            ticks = 0
        b.calcGravVector(ups)
        b.calcMovement(ups)
        
        ticks += 1
        # ALL CODE TO DRAW SHOULD GO ABOVE THIS COMMENT
         
        # Go ahead and update the screen with what we've drawn.
        pygame.display.flip()
     
        # Limit to 20 frames per second
        clock.tick(ups)
         
    # Close the window and quit.
    # If you forget this line, the program will 'hang'
    # on exit if running from IDLE.
    print "Saving board..."
    with open('board.pk', 'wb') as output:
        pickle.dump(b, output, pickle.HIGHEST_PROTOCOL)
    pygame.quit()
  
if __name__ == "__main__":
    main()
