import mass
import math
import random
import pickle
import board
import itertools

ly = 9461000000000000.0 #light year to meters
au = 149600000000.0 #au to meters
starNum = 1000
massNum = 100
galRadius = 33100000000000000.0
starSystemRadius = 7480000000000.0
gravLimit = 134610000000000.0
planetMinRad = 2439700.0
planetMaxRad = 71492000.0 * 20
planetMinMass = 3.3022 * 10**23
planetMaxMass = 3.7972 * 10**28
asteriodMinRad = 50.0
asteriodMaxRad = 450000.0
asteriodMinMass = 3.09 * 10**9
asteriodMaxMass = 0.95 * 10**21
starMinRad = 1392684000.0
starMaxRad = 450000000000.0 # in meters
starMinMass = 9.9455 * 10**29 #in kg
starMaxMass = 2.98365 * 10**32

def createStar(x, y, starName):
    r = random.random()
    m = ((starMaxMass - starMinMass) * r) + starMinMass
    rad = ((starMaxRad - starMinRad) * r) + starMinRad
    tilium = random.random() * 0.30
    hydrogen = 1 - tilium
    newMass = mass.NaturalMass(m, rad, x, y, "Star", None, None, None, tilium, hydrogen, 0, 0, 0, 0, 0)
    newMass.name = starName
    return newMass

def createAsteriod(star, name):
    start = random.random() * 2*math.pi
    orbit = ((random.random() * math.sqrt(starSystemRadius * 0.1))**2) + (starSystemRadius * 0.45)
    r = random.random()
    m = ((asteriodMaxMass - asteriodMinMass) * r) + asteriodMinMass
    rad = ((asteriodMaxRad - asteriodMinRad) * r) + asteriodMinRad
    tilium = random.random() * 0.5
    hydrogen = random.random() * 0.1
    iron = random.random() * 0.1
    magnesia = random.random() * 0.1
    silica = random.random() * 0.1
    alumina = random.random() * 0.09
    titanium = random.random() * 0.01
    newMass = mass.NaturalMass(m, rad, None, None, "Asteriod", star, orbit, start, tilium, hydrogen, iron, magnesia, silica, alumina, titanium)
    newMass.name = name
    return newMass

def createPlanet(star, name):
    start = random.random() * 2*math.pi
    orbit = random.random()**2 * starSystemRadius
    while (orbit < starSystemRadius*0.55 and orbit > starSystemRadius*0.45) or orbit < starMaxRad:
        orbit = random.random()**2 * starSystemRadius
    r = random.random()
    m = ((planetMaxMass - planetMinMass) * r) + planetMinMass
    rad = ((planetMaxRad - planetMinRad) * r) + planetMinRad
    tilium = random.random() * 0.0
    hydrogen = random.random() * 0.0
    iron = random.random() * 0.03
    magnesia = random.random() * 0.03
    silica = random.random() * 0.6
    alumina = random.random() * 0.15
    titanium = random.random() * 0.01
    newMass = mass.NaturalMass(m, rad, None, None, "Planet", star, orbit, start, tilium, hydrogen, iron, magnesia, silica, alumina, titanium)
    newMass.name = name
    return newMass
    #weight, radius, x, y, descriptor, tilium, hydrogen, iron, magnesia, silica, alumina, titanium

def createSolarSystem(x, y, starName):
    #print "Generating star system..."
    s = mass.SolarSystem(x, y)
    s.name = starName
    star = createStar(x, y, starName)
    s.addMass(star)
    s.solarMass = star.weight
    planets = int((4 * random.random()) + 7)
    asteriods = massNum - planets
    letters = ['A','B','C','D','E','F','G','H','I','J','K']
    for x in range(planets):
        name = star.name + " " + letters[x]
        s.addMass(createPlanet(star, name))
    for x in range(asteriods):
        name = star.name + " " + str(x)
        s.addMass(createAsteriod(star, name))
    return s

# This is some code to make a spiral galaxy. This galaxy will have two arms, each one being 0.1 * galRadius wide. r = ae^(bt) . t = degree from -2pi to 0. a = galRadius*0.95 . b = 0.4686
# Make the other universe creation code into a function called createEllipticalGalaxy(b)
def createSpiralGalaxy(galRadius):
    armWidth = 0.1 #Fraction of galRadius
    spiRad = -4 * math.pi #in radians, how far you want the arm to swing around
    t = random.random() * spiRad
    ba = math.log((armWidth/2)/(1 - (armWidth/2)))/spiRad
    x = (galRadius*(1 - armWidth/2)) * math.e **(ba * t) * math.cos(t)
    y = (galRadius*(1 - armWidth/2)) * math.e **(ba * t) * math.sin(t)
    tx = random.random() * armWidth * galRadius
    ty = random.random() * armWidth * galRadius
    x = x - (galRadius*(armWidth/2)) + tx
    y = y - (galRadius*(armWidth/2)) + ty
    if random.random() >0.5:
        x = -1*x
        y = -1*y
    l = mass.Location(x, y)
    return l

def createEllipticalGalaxy(galRadius):
    randA = random.random() * 360
    randA = math.radians(randA)
    randR = (random.random() * math.sqrt(galRadius))**2
    x = randR * math.cos(randA)
    y = randR * math.sin(randA)
    l = mass.Location(x, y)
    return l

def starName(starNames):
    b = random.choice(starNames)
    starNames.remove(b)
    c = ""
    for x in b:
        c += x
    return c

yes = raw_input("Warning! This will overwrite any pre-existing universe in this directory! Enter \"Y\" to continue!")
if yes != "Y":
    1+1
    print "Exiting program."

else:
    starYes = raw_input("Would you like to change the default amount of stars from 1000? Y or N")
    if starYes == "Y":
        try:
            starNum = int(raw_input("How many stars would you like in the galaxy?"))
        except ValueError:
            starNum = 1000
            print "Invalid entry, number of stars is 1000"

    massYes = raw_input("Would you like to change the default amount of masses in a star system from 100? Y or N")
    if massYes == "Y":
        try:
            massNum = int(raw_input("How many masses would you like in a star system?"))
        except ValueError:
            massNum = 100
            print "Invalid entry, number of masses is 100"

    galYes = raw_input("Would you like to change the default galactic radius from 33100000000000000 meters? Y or N")
    if starYes == "Y":
        try:
            galRadius = int(raw_input("What would you like the galactic radius to be in meters?"))
        except ValueError:
            galRadius = 33100000000000000.0
            print "Invalid entry, galactic radius is 33100000000000000"

    print "Generating galaxy..."
    
    b = board.Board(galRadius)
    
    vowels = ['a','e','i','o','u']
    cons = ['b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z']
    names = [cons,vowels,cons,vowels]
    starNames = list(itertools.product(*names))

    b.addSolarSystem(createSolarSystem(0,0,starName(starNames)))
    "Generated star system 0"
    
    for i in range(starNum-1):
        t = True
        while t:
            t = False
            #l = createEllipticalGalaxy(galRadius)
            l = createSpiralGalaxy(galRadius)
            for sv in b.solarSystems:
                s = b.solarSystems[sv]
                sl = mass.Location(s.x, s.y)
                if l.distance(sl) < gravLimit:
                    t = True
        x = l.x
        y = l.y
        b.addSolarSystem(createSolarSystem(x, y,starName(starNames)))
        if i%100 == 0:
            print "Generated star system ", i+1
        i = i + 1

    ship = mass.ArtMass(100.0, 10.0, 74798935350.0, 74798935350.0, "Ship", None, None, None, mass.Vector(), 0)
    b.addArtMass(ship)
    b.userShip = ship.i

    #Now save the board as a file
    with open('board.pk', 'wb') as output:
        pickle.dump(b, output, pickle.HIGHEST_PROTOCOL)

##  This code can open a file and load it as an object
##  b = None
##  with open('board.pk', 'rb') as input:
##      b = pickle.load(input)

    import visual
    visual.main()
