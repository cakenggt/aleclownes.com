#from graphics import *
import math
import mass

g = 0.00000000006674 #G per second
gravT = 1 #how many gravity vector updates per second
gravLimit = 134610000000000.0 #how away something must be for its gravity to not matter, currently 30 AU
moveT = 20 #how many movement calculations per second
jumpRad = 2388000000000000
maxThrust = 5 #change this later
lightSpeed = 299792458
hyperSpeed = 11000 * lightSpeed

class Board():

    def __init__(self, galRadius):
        self.galRadius = galRadius
        self.artMasses = {}
        self.solarSystems = {}
        self.jumpRad = jumpRad
        self.maxThrust = maxThrust
        userShip = None

    def addSolarSystem(self, s):
        self.solarSystems[s.name] = s

    def addArtMass(self, m):
        self.artMasses[m.i] = m

    def calcGravVector(self, gravT = 1):
        A = self.solarSystems
        B = self.artMasses
        for i in B:
            n = B[i]
            t = True
            for dv in A:
                d = A[dv]
                if t:
                    if n.distance(d) < gravLimit:
                        t = False
                        for v in d.masses:
                            m = d.masses[v]
                            if m.descriptor == "Star":
                                mx = m.x
                                my = m.y
                            else:
                                mx, my = m.getXY()
                            r2 = (n.x - mx)**2 + (n.y - my)**2
                            f = g * ((n.weight * m.weight)/r2) #force of gravity
                            #acceleration for each
                            an = f/n.weight
                            #velocities
                            vn = an/(gravT**2)
                            #vector of gravitational pull
                            nGrav = mass.Vector((mx - n.x), (my - n.y))
                            #making them unit vectors
                            nGrav.unit()
                            #points the velocity in the gravitational pull direction
                            nGrav.multiply(vn)
                            #adds this new velocity to the current mass's velocity
                            n.vector.add(nGrav)
                            self.artMasses[i] = n #adds new n back into masses

    def calcMovement(self, moveT = 20):
        for i in self.artMasses:
            m = self.artMasses[i]
            m.x = m.x + (m.vector.x/moveT) #adding the velocity divided by the movement time to the x and y coordinates of the mass
            m.y = m.y + (m.vector.y/moveT)
            self.artMasses[i] = m

    def mine(self, ship):
        #This code isn't finished at all, it is just to save some code
        #allowing for the modification of a single item in a list
        #without messing up the list order
        
        #s = do a search for which solarSystem the ship is in, s is that system
        #range = ship.miningRange
        #for i, f in enumerate(s.masses):
        #   if ship.distance(f) < range:
        #       minedWeight = ship.miningPercentage * f.weight
        #       f.weight = f.weight - minedWeight
        #       s.masses[i] = f
        1+1
