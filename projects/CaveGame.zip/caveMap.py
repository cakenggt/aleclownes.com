import pickle
import caveObjects

#  #for rock, ' ' for room, letters for ores, '@' for player, 'P' for portal

size = 25

w = None
with open('map.pk', 'rb') as inputf:
    w = pickle.load(inputf)
action = None
tl = sorted(list(w.towns.keys()))
for x in tl:
    print(x)
while action not in w.towns:
    action = input("What town would you like to see?")
town = w.towns[action]
level = 0
while action != 'q':
    if action == 'z':
        level += 1
    if action == 'x':
        level -= 1
    if action != 'quit':
        sd = ""
        for x in range(size):
            sd += " "
        sd += str(level)
        print(sd)
        s = ""
        for x in range(size):
            s += " "
        s += "0"
        print(s)
        for y in range(-1 * size,size + 1):
            y *= -1
            s = ""
            s += str(y)
            for b in range(3-len(str(y))):
                s += ' '
            for x in range(-1 * size,size + 1):
                loc = (x,y,level)
                if loc in town.roomsAndOres:
                    e = town.roomsAndOres[loc]
                    if loc == tuple(w.player.location[1:]):
                        s += "@"
                    elif loc == town.portal:
                        s += "P"
                    elif isinstance(e,caveObjects.Room):
                        s += " "
                    elif isinstance(e,caveObjects.Ore):
                        s += e.ore[0]
                else:
                    s += "#"
            print(s)
        action = input("z to go up, x to go down, or q to quit.")
