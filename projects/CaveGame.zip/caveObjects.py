#These are the objects for CaveGame
import random
import math

debug = True
debug2 = False

class World():
    def __init__(self):
        self.towns = {}
        player = Player(self, ["Town1",0,0,0])
        if debug:
            player.addItem(Pickaxe)
            for x in range(20):
                player.addItem(Rope)
            for x in range(10):
                player.addItem(Soylent)
            player.addItem(Compass)
            player.addItem(Dynamite)
            player.addItem(Dynamite)
            player.addItem(Flashlight)
            player.addItem(Battery)
            player.addItem(Battery)
            player.money = 1000.0
        self.player = player
        self.seed = str(random.randrange(99999999))

    def quanCheck(self):
        #This checks the quantities and health of stacks and removes ones at 0
        for x in self.towns:
            for y in self.towns[x].roomsAndOres:
                if isinstance(self.towns[x].roomsAndOres[y],Room):
                    c = []
                    for z in self.towns[x].roomsAndOres[y].contains:
                        if z.quantity > 0 and (z.health > 0 or not z.useUp):
                            c.append(z)
                    self.towns[x].roomsAndOres[y].contains = c
        c = []
        for x in self.player.inventory:
            if x.quantity > 0 and (x.health > 0 or not x.useUp):
                c.append(x)
        self.player.inventory = c

    def itemFall(self):
        for x in self.towns:
            c = []
            for y in self.towns[x].roomsAndOres:
                if isinstance(self.towns[x].roomsAndOres[y],Room):
                    c.append(y)
            c = sorted(c,key=lambda x: x[2])
            c.reverse()
            for z in c:
                below = (z[0],z[1],z[2]-1)
                if below in c and len(self.towns[x].roomsAndOres[z].contains)>0:
                    self.towns[x].roomsAndOres[below].contains.extend(self.towns[x].roomsAndOres[z].contains)
                    self.towns[x].roomsAndOres[z].contains = []

class Town():
    def __init__(self, name):
        self.name = name
        self.roomsAndOres = {}
        self.portal = None

    def makePortal(self):
        c = []
        for y in self.roomsAndOres:
            if isinstance(self.roomsAndOres[y],Room):
                c.append(y)
        c = sorted(c,key=lambda x: x[2])
        lowest = c[0]
        portal = Room((lowest[0],lowest[1],lowest[2]-1))
        self.roomsAndOres[portal.loc] = portal
        self.portal = portal.loc
        if debug2:
            self.portal = (0,1,-1)
    
class Room():
    def __init__(self, loc):
        self.loc = loc #the location in format (x,y,z)
        self.contains = []
        self.rope = False
        self.hewn = False
        self.prog = 0 #hits it takes to make the room walkable. When you hew rock, it starts off at 500

    def mine(self, player):
        i = []
        for x in player.inventory:
            i.append(x.name)
        if "Pickaxe" in i:
            picki = i.index("Pickaxe")
            if self.prog >0:
                pick = player.inventory[picki]
                pick.health -= 1
                player.inventory[picki] = pick
                self.prog -= 1
                print("Your pickaxe bites into the rock.")     
                player.getRoom().addItem(Stone.copy())
            else:
                print("You cannot mine air.")
        else:
            print("You cannot mine without a pickaxe.")

    def addItem(self, item):
        names = []
        for x in self.contains:
            names.append(x.name)
        if item.stackable and (item.name in names):
            ind = names.index(item.name)
            self.contains[ind].quantity += 1
        else:
            self.contains.append(item.copy())

    def remItem(self, i, num):
        item = self.contains[i].copy()
        if num <= item.quantity:
            item.quantity = num
        self.contains[i].quantity -= num
        return item

    def weight(self):
        w = 0
        for x in self.contains:
            w += x.weight * x.quantity
        return w

    def blast(self, player):
        i = []
        for x in player.inventory:
            i.append(x.name)
        if "Dynamite" in i:
            picki = i.index("Dynamite")
            if self.prog >0:
                player.remItem(picki,1)
                pr = self.prog
                self.prog = 0
                print("The dynamite reduces the rock wall to rubble.")
                for x in range(pr):
                    player.getRoom().addItem(Stone.copy())
            else:
                print("You cannot blast air.")
        else:
            print("You cannot blast without dynamite.")

class Ore():
    def __init__(self, loc, chance):
        self.loc = loc
        self.ore = "" #the name of the mineral
        self.chance = chance
        self.prog = 500

    def desc(self):
        if self.chance<0.3:
            return "lesser"
        elif self.chance>=0.3 and self.chance<=0.4:
            return "medium"
        else:
            return "rich"

    def mine(self, player):
        i = []
        for x in player.inventory:
            i.append(x.name)
        if "Pickaxe" in i:
            picki = i.index("Pickaxe")
            if self.prog >0:
                pick = player.inventory[picki]
                pick.health -= 1
                player.inventory[picki] = pick
                self.prog -= 1
                print("Your pickaxe bites into the rock.")
                if random.random() < self.chance:
                    n = Nugget.copy()
                    n.name = self.ore
                    player.getRoom().addItem(n)
                else:
                    player.getRoom().addItem(Stone.copy())
                if self.prog <= 0:
                    room = Room(self.loc)
                    player.world.towns[player.location[0]].roomsAndOres[self.loc] = room
            else:
                print("You cannot mine air.")
        else:
            print("You cannot mine without a pickaxe.")

    def blast(self, player):
        i = []
        for x in player.inventory:
            i.append(x.name)
        if "Dynamite" in i:
            picki = i.index("Dynamite")
            if self.prog >0:
                player.remItem(picki,1)
                pr = self.prog
                print("Your dynamite reduces the ore vein to rubble.")
                for x in range(pr):
                    if random.random() < self.chance:
                        n = Nugget.copy()
                        n.name = self.ore
                        player.getRoom().addItem(n)
                    else:
                        player.getRoom().addItem(Stone.copy())
                room = Room(self.loc)
                player.world.towns[player.location[0]].roomsAndOres[self.loc] = room
            else:
                print("You cannot blast air.")
        else:
            print("You cannot blast without dynamite.")

class Item():
    def __init__(self, name, quantity, stackable, weight, health, useUp):
        self.name = name
        self.quantity = quantity
        self.stackable = stackable #true or false
        self.weight = weight #in kg
        #health is used as hunger restore value in foods
        self.health = health #this is durability, it starts at a number then goes to zero
        self.useUp = useUp #is it used up when health goes to zero

    def copy(self):
        item = Item(self.name,self.quantity,self.stackable,self.weight,self.health,self.useUp)
        return item

class Player():
    #Here is how hunger and energy work:
    #it takes energy to move or mine
    #it takes more energy the more below 50% your hunger is, but not over 50%
    #it takes more energy to move the more mass contained in a room
    #when you sleep, your food is turned into energy at rate x
    # x is 1 if you sleep in inn or sleeping bag, 0.5 ifyou sleep on cave floor
    #if an action takes more energy than you have, you cannot do it
    #this is how you can die of hunger
    def __init__(self, world, location):
        self.location = location #[Town1,0,0,0]
        self.direction = 1 #this is a number between 0 and 3, 0 is right, 1 is up
        self.hunger = 100.0 #tweak this, not a percentage, maybe make it higher
        self.energy = 100.0 #tweak this too
        self.inventory = []
        self.money = 100.0
        self.world = world

    def light(self):
        if self.location[3] >= -1:
            return True
        for flash in self.inventory:
            if flash.name == "Flashlight":
                if flash.health > 0:
                    flash.health -= 1
                    return True
                else:
                    for bat in self.inventory:
                        if bat.name == "Battery":
                            flash.health = 99
                            self.remItem(self.inventory.index(bat),1)
                            return True
        return False
    
    def rope(self,room):
        if (room.loc[0],room.loc[1],room.loc[2]-1) in self.world.towns[self.location[0]].roomsAndOres:
            downv = self.world.towns[self.location[0]].roomsAndOres[(room.loc[0],room.loc[1],room.loc[2]-1)]
            if isinstance(downv,Room):
                if room.rope:
                    return True
                else:
                    names = []
                    for x in self.inventory:
                        names.append(x.name)
                    if "Rope" in names:
                        self.inventory[names.index("Rope")].quantity -= 1
                        room.rope = True
                        return True
                    else:
                        print("You cannot climb into the shaft as you have no rope.")
                        return False
            else:
                return True
        else:
            return True

    def sleep(self):
        room = self.getRoom()
        rate = 0.5
        roll = False
        for x in room.contains:
            if x.name == "Bedroll":
                roll = True
        if room.loc == (0,0,0) or roll:
            rate = 1.0
        need = 100 - self.energy
        if need*(1/rate) < self.hunger:
            self.hunger -= need*(1/rate)
            self.energy = 100
        else:
            self.energy += self.hunger*rate
            self.hunger = 0

    def movEnergy(self, room):
        #this will calculate energy required to move through a room
        #and return true or false whether the person can do the activity
        #if true, it takes out the energy required
        e = 0.0
        roomw = room.weight()
        pw = self.weight()
        e += math.sqrt(roomw)/20.0
        e += pw/10.0
        if self.energy < 20:
            print("You are running low on energy.")
        if self.hunger < 20:
            print("You are running low on hunger.")
        if e <= self.energy:
            self.energy -= e
            self.hunger -= 5
            return True
        else:
            return False

    def mineEnergy(self):
        #this will calculate energy required to mine
        #and return true or false whether the person can do the activity
        #if true, it takes out the energy required
        e = 0.0
        pw = self.weight()
        e += pw/100.0
        if self.energy < 20:
            print("You are running low on energy.")
        if self.hunger < 20:
            print("You are running low on hunger.")
        if e <= self.energy:
            self.energy -= e
            self.hunger -= 5
            return True
        else:
            print("You are too tired to mine.")
            return False

    def getRoom(self):
        room = self.world.towns[self.location[0]].roomsAndOres[(self.location[1],self.location[2],self.location[3])]
        return room
                                                   
    def weight(self):
        w = 0.0
        for x in self.inventory:
            w += x.weight * x.quantity
        return w

    def addItem(self, item):
        names = []
        for x in self.inventory:
            names.append(x.name)
        if item.stackable and (item.name in names):
            ind = names.index(item.name)
            self.inventory[ind].quantity += 1
        else:
            self.inventory.append(item.copy()) 
    
    def view(self):
        #This gives the view to the player of the 6 blocks around them and the one they are on
        p = self
        town = p.location[0]
        loc = (p.location[1],p.location[2],p.location[3])
        room = loc
        up = (loc[0],loc[1],loc[2]+1)
        down = (loc[0],loc[1],loc[2]-1)
        if p.direction == 0:
            front = (loc[0]+1,loc[1],loc[2])
            back = (loc[0]-1,loc[1],loc[2])
            right = (loc[0],loc[1]-1,loc[2])
            left = (loc[0],loc[1]+1,loc[2])
        if p.direction == 1:
            front = (loc[0],loc[1]+1,loc[2])
            back = (loc[0],loc[1]-1,loc[2])
            right = (loc[0]+1,loc[1],loc[2])
            left = (loc[0]-1,loc[1],loc[2])
        if p.direction == 2:
            front = (loc[0]-1,loc[1],loc[2])
            back = (loc[0]+1,loc[1],loc[2])
            right = (loc[0],loc[1]+1,loc[2])
            left = (loc[0],loc[1]-1,loc[2])
        if p.direction == 3:
            front = (loc[0],loc[1]-1,loc[2])
            back = (loc[0],loc[1]+1,loc[2])
            right = (loc[0]-1,loc[1],loc[2])
            left = (loc[0]+1,loc[1],loc[2])
        #This returns only coordinates in tuples, not actual rooms
        return room, down, front, right, left, back, up

    def turn(self, d):
        if d == "Right":
            self.direction -= 1
        if d == "Left":
            self.direction += 1
        self.direction = self.direction%4

    def remItem(self, i, num):
        item = self.inventory[i].copy()
        if num <= item.quantity:
            item.quantity = num
        self.inventory[i].quantity -= num
        return item

#variables
swings = 500

#Items
#when you add a new item, make sure to add it to caveGame.storeNames and caveGame.store
#name, quantity, stackable, weight, health, useUp
Pickaxe = Item("Pickaxe",1,False,4,3*swings,True)
Flashlight = Item("Flashlight",1,False,1,0,False)
Battery = Item("Battery",1,True,1,100,True)
Rope = Item("Rope",1,True,1,0,False)
#stone is density of 2658kg/m^3, or 21264kg for one room
Stone = Item("Stone",1,True,int(21264.0/swings),0,False)
Nugget = Item("Nugget",1,True,int(21264.0/swings),0,False)
Bedroll = Item("Bedroll",1,True,1,0,False)
Soylent = Item("Soylent",1,True,1,75,False)
EnergyBar = Item("Energy Bar",1,True,1,10,False)
Compass = Item("Compass",1,True,1,0,False)
Dynamite = Item("Dynamite",1,True,1,500,False)
