import math
import random
import caveObjects
import pickle

def main():
    w = None
    with open('map.pk', 'rb') as inputf:
        w = pickle.load(inputf)
    print("Welcome to Cave Game!")
    action = None
    turns = 0
    while action != "q" and action != 'quit':
        action = input("What do you want to do?")
        print()
        print()
        print()
        p = w.player
        room, down, front, right, left, back, up = p.view()
        store = {caveObjects.Dynamite:100,caveObjects.Pickaxe:50,caveObjects.Flashlight:20,caveObjects.Battery:10,caveObjects.Rope:2,caveObjects.Stone:0,caveObjects.Compass:50,caveObjects.Bedroll:20,caveObjects.Soylent:10,caveObjects.EnergyBar:2}
        storeOres = {"Coal":2,"Silver":5,"Gold":10,"Iron":3,"Uranite":20}
        storeNames = {"Dynamite":100,"Pickaxe":50,"Flashlight":20,"Battery":10,"Rope":2,"Stone":0,"Bedroll":20,"Soylent":10,"EnergyBar":2,"Compass":50,"Coal":2,"Silver":5,"Gold":10,"Iron":3,"Uranite":20}
        townColors = {"Town1":"blue","Town2":"cerulean","Town3":"emerald","Town4":"indigo","Town5":"mauve"}
        upTown = None
        downTown = None
        if p.location[0] != 'Town1':
            upTown = 'Town' + str(int(p.location[0][-1])-1)
        if p.location[0] != 'Town5':
            downTown = 'Town' + str(int(p.location[0][-1])+1)
        #viewing your surroundings
        if action == 'v' or action == 'view':
            if p.light() or up[2] >= 0:
                seed = random.seed(w.seed + str(p.location) + "desc")
                seedDescription = ["You are in a room with ",None," stalactites, ",None," rock, and a ",None," stream."]
                seedDescription[1] = random.choice(['no','few','clustered','sparse','long','short','many'])
                seedDescription[3] = random.choice(['black','red','porous','slimy','glass-like','sharp','yellow'])
                seedDescription[5] = random.choice(['dry','trickling','roaring','cloudy','clear'])
                random.seed()
                seedDesc = ""
                for x in seedDescription:
                    seedDesc += x
                if p.location[3] < -1:
                    print(seedDesc)
                if up in w.towns[p.location[0]].roomsAndOres:
                    if up[2] >= 0:
                        print("Light shines down on you from a " + townColors[p.location[0]] + " sky.")
                    else:
                        upv = w.towns[p.location[0]].roomsAndOres[up]
                        if isinstance(upv,caveObjects.Room):
                            if upv.hewn:
                                print("A roughly hewn shaft extends upwards above you.")
                            else:
                                print("A smooth rock shaft extends upwards above you.")
                        if isinstance(upv,caveObjects.Ore):
                            print("There is a vein of " + upv.ore + " in the ceiling of the cavern.")
                            if upv.prog == 500:
                                print("There is an untouched " + upv.desc() + " vein of " + upv.ore + " in the ceiling of the cavern.")
                            else:
                                print("There is a partially mined " + upv.desc() + " vein of " + upv.ore + " in the ceiling of the cavern.")
                else:
                    if up[2] >= 0:
                        print("Light shines down on you from a " + townColors[p.location[0]] + " sky.")
                    else:
                        print("The ceiling is made of low featureless stone.")
                if down in w.towns[p.location[0]].roomsAndOres and not room == w.towns[p.location[0]].portal:
                    if down == (0, 0, -1):
                        print("You are in " + p.location[0])
                    elif down == (0, 1, -1):
                        print("You are dangling over the gaping maw of a cave.")
                    elif down[2] == -1:
                        print("You are standing in a vast field of wheat.")
                    else:
                        downv = w.towns[p.location[0]].roomsAndOres[down]
                        if isinstance(downv,caveObjects.Room):
                            if downv.hewn:
                                print("You dangle above a roughly hewn dark pit.")
                            else:
                                print("You dangle above a smooth dark pit.")
                        if isinstance(downv,caveObjects.Ore):
                            if downv.prog == 500:
                                print("There is an untouched " + downv.desc() + " vein of " + downv.ore + " in the floor of the cavern.")
                            else:
                                print("There is a partially mined " + downv.desc() + " vein of " + downv.ore + " in the floor of the cavern.")
                else:
                    if down == (0, 0, -1):
                        print("You are in " + p.location[0])
                    elif down[2] == -1:
                        print("You are standing in a vast field of wheat.")
                    elif room == w.towns[p.location[0]].portal:
                        print("In the floor of the cavern, you see a wide crack glowing with " + townColors[downTown] + " light.")
                    else:
                        print("The ground is made of smooth, hard stone.")
                if front in w.towns[p.location[0]].roomsAndOres:
                    if front[2] == 0:
                        if front[0] == 0 and front[1] == 0:
                            print("The town is in front of you.")
                        elif front[0] == 0 and front[1] == 1:
                            print("In front of you lies a gaping hole in the Earth.")
                        else:
                            print("Tall wheat sways in front of you.")
                    else:
                        frontv = w.towns[p.location[0]].roomsAndOres[front]
                        if isinstance(frontv,caveObjects.Room):
                            if frontv.hewn and frontv.prog == 0:
                                print("There is a roughly hewn passage in front of you.")
                            elif frontv.prog != 0:
                                print("The rock wall in front of you has been partially mined away.")
                            else:
                                print("There is a passage in front of you.")
                        if isinstance(frontv,caveObjects.Ore):
                            if frontv.prog == 500:
                                print("There is an untouched " + frontv.desc() + " vein of " + frontv.ore + " in the wall in front of you.")
                            else:
                                print("There is a partially mined " + frontv.desc() + " vein of " + frontv.ore + " in the wall in front of you.")
                else:
                    if front[2] == 0:
                        if front[0] == 0 and front[1] == 0:
                            print("The town is in front of you.")
                        elif front[0] == 0 and front[1] == 1:
                            print("In front of you lies a gaping hole in the Earth.")
                        else:
                            print("Tall wheat sways in front of you.")
                    else:
                        print("There is a solid rock wall in front of you.")
                if back in w.towns[p.location[0]].roomsAndOres:
                    if back[2] == 0:
                        if back[0] == 0 and back[1] == 0:
                            print("The town is behind you.")
                        elif back[0] == 0 and back[1] == 1:
                            print("Behind you lies a gaping hole in the Earth.")
                        else:
                            print("Tall wheat sways behind you.")
                    else:
                        backv = w.towns[p.location[0]].roomsAndOres[back]
                        if isinstance(backv,caveObjects.Room):
                            if backv.hewn and backv.prog == 0:
                                print("There is a roughly hewn passage behind of you.")
                            elif backv.prog != 0:
                                print("The rock wall behind you has been partially mined away.")
                            else:
                                print("There is a passage behind you.")
                        if isinstance(backv,caveObjects.Ore):
                            if backv.prog == 500:
                                print("There is an untouched " + backv.desc() + " vein of " + backv.ore + " in the wall behind you.")
                            else:
                                print("There is a partially mined " + backv.desc() + " vein of " + backv.ore + " in the wall behind you.")
                else:
                    if back[2] == 0:
                        if back[0] == 0 and back[1] == 0:
                            print("The town is behind you.")
                        elif back[0] == 0 and back[1] == 1:
                            print("Behind you lies a gaping hole in the Earth.")
                        else:
                            print("Tall wheat sways behind you.")
                    else:
                        print("There is a solid rock wall behind you.")
                if right in w.towns[p.location[0]].roomsAndOres:
                    if right[2] == 0:
                        if right[0] == 0 and right[1] == 0:
                            print("The town is to your right.")
                        elif right[0] == 0 and right[1] == 1:
                            print("To your right lies a gaping hole in the Earth.")
                        else:
                            print("Tall wheat sways to your right.")
                    else:
                        rightv = w.towns[p.location[0]].roomsAndOres[right]
                        if isinstance(rightv,caveObjects.Room):
                            if rightv.hewn and rightv.prog == 0:
                                print("There is a roughly hewn passage to your right.")
                            elif rightv.prog != 0:
                                print("The rock wall to your left has been partially mined away.")
                            else:
                                print("There is a passage to your right.")
                        if isinstance(rightv,caveObjects.Ore):
                            if rightv.prog == 500:
                                print("There is an untouched " + rightv.desc() + " vein of " + rightv.ore + " in the wall to your right.")
                            else:
                                print("There is a partially mined " + rightv.desc() + " vein of " + rightv.ore + " in the wall to your right.")
                else:
                    if right[2] == 0:
                        if right[0] == 0 and right[1] == 0:
                            print("The town is to your right.")
                        elif right[0] == 0 and right[1] == 1:
                            print("To your right lies a gaping hole in the Earth.")
                        else:
                            print("Tall wheat sways to your right.")
                    else:
                        print("There is a solid rock wall to your right.")
                if left in w.towns[p.location[0]].roomsAndOres:
                    if left[2] == 0:
                        if left[0] == 0 and left[1] == 0:
                            print("The town is to your left.")
                        elif left[0] == 0 and left[1] == 1:
                            print("To your left lies a gaping hole in the Earth.")
                        else:
                            print("Tall wheat sways to your left.")
                    else:
                        leftv = w.towns[p.location[0]].roomsAndOres[left]
                        if isinstance(leftv,caveObjects.Room):
                            if leftv.hewn and leftv.prog == 0:
                                print("There is a roughly hewn passage to your left.")
                            elif leftv.prog != 0:
                                print("The rock wall to your left has been partially mined away.")
                            else:
                                print("There is a passage to your left.")
                        if isinstance(leftv,caveObjects.Ore):
                            if leftv.prog == 500:
                                print("There is an untouched " + leftv.desc() + " vein of " + leftv.ore + " in the wall to your left.")
                            else:
                                print("There is a partially mined " + left.desc() + " vein of " + leftv.ore + " in the wall to your left.")
                else:
                    if left[2] == 0:
                        if left[0] == 0 and left[1] == 0:
                            print("The town is to your left.")
                        elif left[0] == 0 and left[1] == 1:
                            print("To your left lies a gaping hole in the Earth.")
                        else:
                            print("Tall wheat sways to your left.")
                    else:
                        print("There is a solid rock wall to your left.")
            else:
                print("The cave is shrouded in darkness.")
        #going forward
        if action == 'w':
            if front in w.towns[p.location[0]].roomsAndOres:
                if isinstance(w.towns[p.location[0]].roomsAndOres[front],caveObjects.Room):
                    frontv = w.towns[p.location[0]].roomsAndOres[front]
                    if p.movEnergy(frontv):
                        if p.rope(frontv):
                            if w.towns[p.location[0]].roomsAndOres[front].prog == 0:
                                print("You walk forward.")
                                p.location = [p.location[0],front[0],front[1],front[2]]
                            else:
                                print("You cannot walk forward.")
                    else:
                        print("You are too tired to move forward.")
                else:
                    print("You cannot walk forward.")
            else:
                print("You cannot walk forward.")
        #turning left
        if action == 'a':
            p.turn('Left')
            print("You turn left.")
        #turning right
        if action == 'd':
            p.turn("Right")
            print("You turn right.")
        #backing up
        if action == 's':
            if back in w.towns[p.location[0]].roomsAndOres:
                if isinstance(w.towns[p.location[0]].roomsAndOres[back],caveObjects.Room):
                    backv = w.towns[p.location[0]].roomsAndOres[back]
                    if p.movEnergy(backv):
                        if p.rope(backv):
                            if w.towns[p.location[0]].roomsAndOres[back].prog == 0:
                                print("You back up")
                                p.location = [p.location[0],back[0],back[1],back[2]]
                            else:
                                print("You cannot back up.")
                    else:
                        print("You are too tired to back up.")
                else:
                    print("You cannot back up.")
            else:
                print("You cannot back up.")
        #climbing up
        if action == 'up':
            if room == (0,0,0) and p.location[0] != "Town1":
                print("You climb up through the crack in the " + townColors[p.location[0]] + " sky into a dark cave.")
                l = [upTown]
                l.extend(w.towns[upTown].portal)
                p.location = l
            elif up in w.towns[p.location[0]].roomsAndOres:
                if isinstance(w.towns[p.location[0]].roomsAndOres[up],caveObjects.Room):
                    upv = w.towns[p.location[0]].roomsAndOres[up]
                    if p.movEnergy(upv):
                        if p.rope(upv):
                            if w.towns[p.location[0]].roomsAndOres[up].prog == 0:
                                print("You climb up")
                                p.location = [p.location[0],up[0],up[1],up[2]]
                            else:
                                print("You cannot climb up.")
                    else:
                        print("You are too tired to climb up.")
                else:
                    print("You cannot climb up.")
            else:
                print("You cannot climb up.")
        #climbing down
        if action == 'down':
            if room == w.towns[p.location[0]].portal and p.location[0] != "Town5":
                print("You climb down through the " + townColors[downTown] + " crack into a new town.")
                p.location = [downTown,0,0,0]
            elif down in w.towns[p.location[0]].roomsAndOres:
                if isinstance(w.towns[p.location[0]].roomsAndOres[down],caveObjects.Room):
                    downv = w.towns[p.location[0]].roomsAndOres[down]
                    if p.movEnergy(downv):
                        if p.rope(downv):
                            if w.towns[p.location[0]].roomsAndOres[down].prog == 0:
                                print("You climb down")
                                p.location = [p.location[0],down[0],down[1],down[2]]
                            else:
                                print("You cannot climb down.")
                    else:
                        print("You are too tired to climb down.")
                else:
                    print("You cannot climb down.")
            else:
                print("You cannot climb down.")
        #gps
        if action == 'gps' and caveObjects.debug:
            print(p.location)
        #mining
        if action == 'm' or action == 'mine':
            if front in w.towns[p.location[0]].roomsAndOres:
                frontv = w.towns[p.location[0]].roomsAndOres[front]
                if front[2] == 0:
                    print("You cannot mine above ground.")
                else:
                    if p.mineEnergy():
                        frontv.mine(p)
            else:
                if p.mineEnergy():
                    i = []
                    for x in p.inventory:
                        i.append(x.name)
                    if "Pickaxe" in i:
                        room = caveObjects.Room(front)
                        room.prog = caveObjects.swings
                        w.towns[p.location[0]].roomsAndOres[front] = room
                        frontv = w.towns[p.location[0]].roomsAndOres[front]
                        frontv.mine(p)
                    else:
                        print("You cannot mine without a pickaxe.")
        #inventory
        if action == 'i' or action == 'inventory':
            if len(p.inventory) == 0:
                print("There is nothing in your inventory.")
            else:
                print("The following items are in your inventory.")
                print("No. Name       Quantity   Weight     Health")
            for ind, i in enumerate(p.inventory):
                sd = [str(ind),str(i.name),str(i.quantity),str(i.weight),str(i.health)]
                s = ""
                for indi, x in enumerate(sd):
                    s += x
                    spaces = ""
                    if indi == 0:
                        for v in range(4-len(x)):
                            spaces += " "
                    else:
                        for v in range(11-len(x)):
                            spaces += " "
                    s += spaces
                print(s)
        #examine
        if action == 'e' or action == 'examine':
            if down == (0, 0, -1):
                if len(p.getRoom().contains) > 0:
                    print("You find the following on the floor of your room in the inn.")
                    print("No. Name      Quantity  Weight    Health")
                else:
                    print("Your room at the inn is empty.")
            else:
                if len(p.getRoom().contains) > 0:
                    print("You find the following on the floor of the cavern you are in.")
                    print("No. Name       Quantity   Weight     Health")
                else:
                    print("The cavern you are in is empty and dark.")
            for ind, i in enumerate(p.getRoom().contains):
                sd = [str(ind),str(i.name),str(i.quantity),str(i.weight),str(i.health)]
                s = ""
                for indi, x in enumerate(sd):
                    s += x
                    spaces = ""
                    if indi == 0:
                        for v in range(4-len(x)):
                            spaces += " "
                    else:
                        for v in range(11-len(x)):
                            spaces += " "
                    s += spaces
                print(s)
        #drop item
        if action.split()[0] == 'drop':
            if len(action.split()) == 1:
                print("Specify the object's number.")
            else:
                i = int(action.split()[1])
                num = 1
                if len(action.split()) == 3:
                    num = int(action.split()[2])
                if len(p.inventory) > i and i >= 0:
                    item = p.remItem(i,num)
                    room = p.getRoom()
                    room.addItem(item)
                    print("You have dropped " + str(item.quantity) + " " + item.name + ".")
                else:
                    print("That item number does not exist in your inventory.")
        #grab item
        if action.split()[0] == 'grab':
            if len(action.split()) == 1:
                print("Specify the object's number.")
            else:
                i = int(action.split()[1])
                num = 1
                if len(action.split()) == 3:
                    num = int(action.split()[2])
                room = p.getRoom()
                if len(room.contains) > i and i >= 0:
                    item = room.remItem(i,num)
                    p.addItem(item)
                    print("You have picked up " + str(item.quantity) + " " + item.name + ".")
                else:
                    print("That item number does not exist in this room.")
        #sleep
        if action == 'sleep':
            if p.hunger > 0:
                p.sleep()
                print("You go to sleep.")
                print("You have woken up.")
            else:
                print("You are too hungry to go to sleep.")
        #status
        if action == 'status':
            print("Your hunger is " + str(p.hunger))
            print("Your energy is " + str(p.energy))
            print("You have $" + str(p.money) + ".")
            print("Everything you are carrying weighs " + str(p.weight()) + " kg.")
        #eat
        if action.split()[0] == 'eat':
            if len(action.split()) == 1:
                print("The following items are in your inventory.")
                print("No. Name       Quantity   Weight     Health")
                for ind, i in enumerate(p.inventory):
                    sd = [str(ind),str(i.name),str(i.quantity),str(i.weight),str(i.health)]
                    s = ""
                    for indi, x in enumerate(sd):
                        s += x
                        spaces = ""
                        if indi == 0:
                            for v in range(4-len(x)):
                                spaces += " "
                        else:
                            for v in range(11-len(x)):
                                spaces += " "
                        s += spaces
                    print(s)
                print("Specify the object's number.")
            else:
                i = int(action.split()[1])
                if len(p.inventory) > i and i >= 0:
                    item = p.inventory[i]
                    if item.name in ["Soylent","Energy Bar"]:
                        num = 1
                        if len(action.split()) == 3:
                            num = int(action.split()[2])
                        item = p.remItem(i,num)
                        p.hunger += item.quantity * item.health
                        if p.hunger >100:
                            p.hunger = 100
                        print("You have eaten " + str(item.quantity) + " " + item.name + ".")
                    else:
                        print(item.name + " is not edible.")
                else:
                    print("That item number does not exist in your inventory.")
        #help
        if action == "help" or action == "?":
            print("You are playing Cave Game by Alec Lownes.")
            print("The object of this game is to explore the cave in front of the village.")
            print("")
            print("Here are the commands you can enter and their effects:")
            print("v or view: Tells you about your surroundings.")
            print("w: Your player will move forward if they are able to.")
            print("s: Your player will move backward if they are able to.")
            print("a: Your player will turn left.")
            print("d: Your player will turn right.")
            print("up: Your player will climb up if they are able to.")
            print("down: Your player will climb down if they are able to.")
            print("gps: This tells you what your player's location is.")
            print("m or mine: If you have a pickaxe in your inventory, your player will attempt to mine what is in front of them.")
            print("i or inventory: This tells you what is in your player's inventory.")
            print("e or examine: This tells you what the room you are in contains.")
            print("drop x1 x2: This will drop item number x1 from your inventory. You can optionally include how many of the item you would like to drop, which is x2.")
            print("grab x1 x2: This will grab item number x1 from the room's inventory. You can optionally include how many of the item you would like to grab, which is x2.")
            print("sleep: This makes you sleep. Your hunger level is added to your energy level and your hunger is reduced to zero.")
            print("status: This tells you what your energy, hunger, money, and weight are.")
            print("eat x1 x2: This will make you eat item x1 in your inventory if it is food. You can optionally specify a quantity with x2.")         
            print("work: This makes you work for a wage in the town. Your energy is converted to money.")
            print("buy x1 x2: You can buy materials in the town. With no arguments, it will print the list of things you can buy. You can specify which object with x1 and quantity with x2.")
            print("sell x1 x2: You can sell materials from your inventory in the town. With no arguments, it lists the things you can sell. You can specify which object with x1 an quantity with x2.")
            print("save: saves the game.")
            print("compass: If you have a compass, it tells you which direction you are facing.")
        #work
        if action == "work":
            if p.location[1:] == [0,0,0]:
                money = p.energy
                p.energy = 0
                p.money += money
                print("You work and earn $" + str(money) + ", you are now exhausted.")
            else:
                print("You must be in town to work.")
        #buy
        if action.split()[0] == "buy":
            if p.location[1:] == [0,0,0]:
                storeKeys = list(store.keys())
                storeKeys = sorted(storeKeys,key=lambda x: x.name)
                if len(action.split()) == 1:
                    print("Store inventory:")
                    print("No. Name       Price")
                    for ind, i in enumerate(storeKeys):
                        sd = [str(ind),str(i.name),str(store[i])]
                        s = ""
                        for indi, x in enumerate(sd):
                            s += x
                            spaces = ""
                            if indi == 0:
                                for v in range(4-len(x)):
                                    spaces += " "
                            else:
                                for v in range(11-len(x)):
                                    spaces += " "
                            s += spaces
                        print(s)
                    print("Specify the object's number and, optionally, quantity.")
                else:
                    i = int(action.split()[1])
                    num = 1
                    if len(action.split()) == 3:
                        num = int(action.split()[2])
                    if len(store) > i and i >= 0:
                        item = storeKeys[i]
                        if p.money >= store[item] * num:
                            for x in range(num):
                                p.addItem(item)
                            print("You have bought " + str(num) +  " " + item.name + ".")
                            p.money -= store[item] * num
                        else:
                            print("You do not have enough money.")
                    else:
                        print("That item number is not in the store.")
            else:
                print("You must be in town to buy items.")
        #sell
        if action.split()[0] == "sell":
            if p.location[1:] == [0,0,0]:
                if len(action.split()) == 1:
                    print("Inventory:")
                    print("No. Name       Price")
                    for ind, i in enumerate(p.inventory):
                        sd = [str(ind),str(i.name),str(storeNames[i.name])]
                        s = ""
                        for indi, x in enumerate(sd):
                            s += x
                            spaces = ""
                            if indi == 0:
                                for v in range(4-len(x)):
                                    spaces += " "
                            else:
                                for v in range(11-len(x)):
                                    spaces += " "
                            s += spaces
                        print(s)
                    print("Specify the object's number and, optionally, quantity.")
                else:
                    i = int(action.split()[1])
                    num = 1
                    if len(action.split()) == 3:
                        num = int(action.split()[2])
                    if len(p.inventory) > i and i >= 0:
                        price = storeNames[p.inventory[i].name]
                        invNum = p.inventory[i].quantity
                        p.remItem(i, num)
                        print("You have sold " + str(invNum) +  " " + p.inventory[i].name + ".")
                        p.money += price * invNum
                    else:
                        print("That item number is not in your inventory.")
            else:
                print("You must be in town to sell items.")
        #save
        if action == 'save':
            with open('map.pk', 'wb') as output:
                pickle.dump(w, output, pickle.HIGHEST_PROTOCOL)
        #compass
        if action == 'compass':
            c = False
            for comp in p.inventory:
                if comp.name == "Compass":
                    c = True
            if c:
                s = ""
                if p.direction == 0:
                    s = "East."
                elif p.direction == 1:
                    s = "North."
                elif p.direction == 2:
                    s = "West."
                elif p.direction == 3:
                    s = "South."
                print("You are facing " + s)
            else:
                print("You do not have a Compass.")
        #blast
        if action == 'blast':
            if front in w.towns[p.location[0]].roomsAndOres:
                frontv = w.towns[p.location[0]].roomsAndOres[front]
                if front[2] == 0:
                    print("You cannot blast above ground.")
                else:
                    frontv.blast(p)
            else:
                i = []
                for x in p.inventory:
                    i.append(x.name)
                if "Dynamite" in i:
                    room = caveObjects.Room(front)
                    room.prog = caveObjects.swings
                    w.towns[p.location[0]].roomsAndOres[front] = room
                    frontv = w.towns[p.location[0]].roomsAndOres[front]
                    frontv.blast(p)
                else:
                    print("You cannot blast without dynamite.")

        #checks the quantities of stacks
        w.quanCheck()
        #makes all items fall down shafts
        w.itemFall()
        #This saves the game after each action
        w.player = p
        turns += 1
        if turns == 10:
            with open('map.pk', 'wb') as output:
                pickle.dump(w, output, pickle.HIGHEST_PROTOCOL)
            turns = 0
    with open('map.pk', 'wb') as output:
        pickle.dump(w, output, pickle.HIGHEST_PROTOCOL)
    print("You are quitting Cave Game!")

main()
