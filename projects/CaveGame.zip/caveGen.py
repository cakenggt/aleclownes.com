import random
import math
import caveObjects
import pickle

def makeMap():
    w = caveObjects.World()
    print("World Generating...")
    for i in range(5):
        iv = i+1
        town = caveObjects.Town("Town" + str(iv))
        town.roomsAndOres[(0, 0, 0)] = caveObjects.Room((0, 0, 0))
        town.roomsAndOres[(0, 1, 0)] = caveObjects.Room((0, 1, 0))
        town.roomsAndOres[(0,1,-1)] = caveObjects.Room((0,1,-1))
        town.roomsAndOres[(0,1,-2)] = caveObjects.Room((0,1,-2))
        rms = roomGen(100*iv,(0,1,-2))
        rms2 = []
        for d in range(iv*5):
            rms2 = roomGen(iv*5,random.choice(rms).loc)
            for rd in rms2:
                rms.append(rd)
        for r in rms:
            town.roomsAndOres[r.loc] = r
        ors = oreGen(town.roomsAndOres,25*iv)
        for o in ors:
            if o.loc not in town.roomsAndOres:
                town.roomsAndOres[o.loc] = o
        if iv < 5:
            town.makePortal()
        w.towns[town.name] = town
    with open('map.pk', 'wb') as output:
        pickle.dump(w, output, pickle.HIGHEST_PROTOCOL)
    print("World Saved!")
    if caveObjects.debug:
        statsw(w)

def roomGen(x, start):
    #x,y,z
    #direction 0 is to the right
    v = []
    ds = [0,1,2,3,'D']
    ls = [1,2,3,4]
    for i in range(x):
        if len(v)<1:
            tor = start
        else:
            tor = v[-1].loc
        d = random.choice(ds)
        #lon = random.choice(ls)
        lon = 1
        if d == 'D':
            for i in range(lon):
                tor = (tor[0],tor[1],tor[2]-1)
                room = caveObjects.Room(tor)
                v.append(room)
        if d == 0:
            for i in range(lon):
                tor = (tor[0]+1,tor[1],tor[2])
                room = caveObjects.Room(tor)
                v.append(room)
        if d == 1:
            for i in range(lon):
                tor = (tor[0],tor[1]+1,tor[2])
                room = caveObjects.Room(tor)
                v.append(room)
        if d == 2:
            for i in range(lon):
                tor = (tor[0]-1,tor[1],tor[2])
                room = caveObjects.Room(tor)
                v.append(room)
        if d == 3:
            for i in range(lon):
                tor = (tor[0],tor[1]-1,tor[2])
                room = caveObjects.Room(tor)
                v.append(room)
        if len(v) >= 3:
            if tor is v[-3]:
                tor = v[-2]
                for i in range(lon):
                    tor = (tor[0],tor[1],tor[2]-1)
                    room = caveObjects.Room(tor)
                    v.append(room)
    return v

def oreGen(rooms,x):
    #x,y,z
    #direction 0 is to the right
    vb = []
    ds = [0,1,2,3,'D']
    ls = [1,2,3,4,5,6,7]
    for ib in range(int(x/5)):
        start = rooms[random.choice(list(rooms.keys()))].loc
        v = []
        oreNames = ['Coal','Silver','Gold','Iron','Uranite']
        oreName = random.choice(oreNames)
        for i in range(5):
            iv = i+1
            if len(v)<1:
                tor = start
            else:
                tor = v[-1].loc
            d = random.choice(ds)
            #lon = random.choice(ls)
            lon = 1
            if d == 'D':
                for i in range(lon):
                    tor = (tor[0],tor[1],tor[2]-1)
            if d == 0:
                for i in range(lon):
                    tor = (tor[0]+1,tor[1],tor[2])
            if d == 1:
                for i in range(lon):
                    tor = (tor[0],tor[1]+1,tor[2])
            if d == 2:
                for i in range(lon):
                    tor = (tor[0]-1,tor[1],tor[2])
            if d == 3:
                for i in range(lon):
                    tor = (tor[0],tor[1]-1,tor[2])
            if len(v) >= 2:
                if tor is v[-2]:
                    for i in range(lon):
                        tor = (tor[0],tor[1],tor[2]-1)
            ore = caveObjects.Ore(tor, 1.1**iv-1)
            #generate the name of ore randomly
            ore.ore = oreName
            v.append(ore)
        for vi in v:
            vb.append(vi)
    return vb

def statsw(w):
    towns = list(w.towns)
    towns.sort()
    for town in towns:
        print(town)
        print("Distribution of depth:")
        d = {}
        for e in w.towns[town].roomsAndOres:
            keys = list(d.keys())
            if e[2] in keys:
                d[e[2]] = d[e[2]]+1
            else:
                d[e[2]] = 1
        keys = list(d.keys())
        keys.sort()
        for f in keys:
            print(str(f) + " " + str(d[f]))

makeMap()

##  This code can open a file and load it as an object
##  b = None
##  with open('board.pk', 'rb') as input:
##      b = pickle.load(input)
